import 'package:flutter/material.dart';

class Palette{
  static const MaterialColor ktoDark = MaterialColor(
    0x00ff1801,
    <int,Color>{
      50:  Color(0x00ff1801 ),//10%
      100:  Color(0x00ff1801),//20%
      200:  Color(0x00ff1801),//30%
      300:  Color(0x00ff1801),//40%
      400:  Color(0x00ff1801),//50%
      500:  Color(0x00ff1801),//60%
      600:  Color(0x00ff1801),//70%
      700:  Color(0x00ff1801),//80%
      800:  Color(0x00ff1801),//90%
      900:  Color(0x00ff1801),//100%

      // 50:  Color(0x00e61601 ),//10%
      // 100:  Color(0x00cc1301),//20%
      // 200:  Color(0x00b31101),//30%
      // 300:  Color(0x00990e01),//40%
      // 400:  Color(0x00800c01),//50%
      // 500:  Color(0x00660a00),//60%
      // 600:  Color(0x004c0700),//70%
      // 700:  Color(0x00330500),//80%
      // 800:  Color(0x00190200),//90%
      // 900:  Color(0x00000000),//100%
    },
  );
}