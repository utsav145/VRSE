const String HomeRoute = 'home';
const String model1Route = 'model1';
const String model2Route = 'model2';
const String model3Route = 'model3';
const String model4Route = 'model4';
const String AboutRoute = 'about';
const String ProfileRoute = 'profile';