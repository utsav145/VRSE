package com.example.f1_models_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
